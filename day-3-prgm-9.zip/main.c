/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
    int a,b,temp;
    int *p1,*p2;
    printf("Enter the first number a:");
    scanf("%d",&a);
    printf("\nEnter the second number b:");
    scanf("%d",&b);
    p1=&a;
    p2=&b;
    printf("\nTwo numbers before swapping is:%d,%d",*p1,*p2);
    temp=*p1;
    *p1=*p2;
    *p2=temp;
    printf("\nTwo numbers after swapping is:%d,%d",*p1,*p2);
    return 0;
}
    
    
    
