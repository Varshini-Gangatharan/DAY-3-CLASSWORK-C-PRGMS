/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <stdio.h>
int max(int a, int b);
int main() 
{
    int a, b, maximum;
    printf("Enter any two numbers: ");
    scanf("%d%d", &a ,&b);
    maximum = max(a, b);
    printf("\nMaximum = %d\n", maximum);
    return 0;
}
int max(int a, int b)
{
    if(a>b)
    return a;
    else
    return b;
}

