/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int cube(int num)
{
    return num*num*num;
}
int main()
{
   int num,result;
   printf("Enter a number:");
   scanf("%d",&num);
   result=cube(num);
   printf("The cube of %d is %d",num,result);
   return 0;
}
