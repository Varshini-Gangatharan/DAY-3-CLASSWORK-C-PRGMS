/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
    int a;
    int *p;
    printf("Enter any integer:");
    scanf("%d",&a);
    p=&a;
    printf("Value of integer n:%d\n",a);
    printf("Value of integer n:%d\n",*p);
    printf("Value of integer n:%d\n",*(&a));
    printf("Address of integer n:%u\n",p);
    printf("Address of integer n:%u\n",&a);
}
