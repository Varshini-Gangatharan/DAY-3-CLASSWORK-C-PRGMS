/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <stdio.h>
int power(int num, int pow);
int main() 
{
    int num, result;
    int pow;
    printf("Enter the number: ");
    scanf("%d", &num);
    printf("Enter the power: ");
    scanf("%d", &pow);
    result = power(num, pow);
    printf("%d ^ %d = %d\n", num, pow, result);
    return 0;
}
int power(int num, int pow) 
{
    if (pow == 0) 
    {
        return 1;
    } else if (pow % 2 == 0) 
    {
        int temp = power(num, pow / 2);
        return temp * temp;
    } else {
        int temp = power(num, (pow - 1) / 2);
        return num * temp * temp;
    }
}
